Ejercicios de Haskell para la asignatura Programacion Declarativa. �ste es el temario de dicha asignatura, y por tanto los conceptos de Haskell que se aplican:

	* Introducci�n a Haskell
	* Funciones de orden superior y polimorfismo
	* Definici�n de tipos
	* El sistema de clases de Haskell
	* Programaci�n con listas
	* Programaci�n con �rboles
